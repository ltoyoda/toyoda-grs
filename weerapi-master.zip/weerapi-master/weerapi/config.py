MEMCACHE_KEY = 'weerapi-cache'
MEMCACHE_EXPIRY = 120
MEMCACHE_SERVERS = ['127.0.0.1:11211']

URL = 'http://m.knmi.nl/index.php?i=Actueel&s=tabel_10min_data'
